package asseted1;

import java.util.*;

public class Collection1 {

	public static void main(String[] args) {
		
		//creating arraylist
		ArrayList<String> name= new ArrayList<String>();
		name.add("barkha");
		name.add("aniket");
		name.add("swarna");
		System.out.println("student arraylist : "+name);
		
		//LinkedList creation
		LinkedList<String> city =new LinkedList<String>();
		city.add("pune");
		city.add("nodia");
		city.add("bhubaneswar");
		System.out.println("City name :"+city);
		
		//creating vector
		Vector<Integer> rollNo= new Vector<Integer>();
		rollNo.add(01);
		rollNo.add(02);
		rollNo.add(03);
		System.out.println("Student Roll No :"+rollNo);
		
		
	}

}
