package asseted1;
import java.util.Scanner;
public class ArrayCreation {

	public static void main(String[] args) {
		
		Scanner obj=new Scanner(System.in);
		
		int arr[]=new int[5];
		System.out.println("Enter the 5 array elements");
		for (int i=0;i<arr.length;i++) {
			arr[i]=obj.nextInt();
		}
		System.out.println("Array Values : ");
		for (int i=0;i<arr.length;i++) {
			System.out.println(arr[i]);
		}
		

	}

}
