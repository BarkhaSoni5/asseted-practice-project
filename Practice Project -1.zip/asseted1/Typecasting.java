package asseted1;

public class Typecasting {

	public static void main(String[] args) {
		
		//implicit typecasting
		System.out.println("This is implicit typecasting");
		int n=5;
		System.out.println("value of n : "+n);
		
		float a=n;
		System.out.println("value of a : "+a);
		
		long b=n;
		System.out.println("value of b : "+b);
		
		double c=n;
		System.out.println("value of c : "+c);
		
		// explicit typecasting
		System.out.println("This is explicit typecasting");
		char d='B';
		int m=(int) d;
		System.out.println("Value of m : "+m);
		System.out.println("Value of d : "+d);
		
		
		

	}

}
