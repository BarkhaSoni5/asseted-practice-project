package asseted1;
import java.util.*;
public class Maps1 {
	public static void main(String[] args) {
		
		System.out.println("This is HashMap");
		HashMap<Integer,String> m=new HashMap<Integer,String>(); 
		m.put(1,"Barkha");
		m.put(2,"Aniket");
		m.put(3,"Swarna");
		m.put(4,"Swati");
		for(Map.Entry m1:m.entrySet()){    
		       System.out.println(m1.getKey()+" "+m1.getValue());    
		}
		
		System.out.println("this is tree Map");
		TreeMap<Integer,String> n=new TreeMap<Integer,String>(); 
		n.put(1,"Barkha");
		n.put(2,"Aniket");
		n.put(3,"Swarna");
		n.put(4,"Swati");
		for(Map.Entry n1:n.entrySet()){    
		       System.out.println(n1.getKey()+" "+n1.getValue());    
		}
		
		      

		
		
		
	}
	

}
