package asseted1;

class privateAccess{
	private void display() {
		System.out.println("This is private modifier");
	}
}
public class AccessModifier2 {

	public static void main(String[] args) {
		System.out.println("Private Accesss Modifier");
		privateAccess m=new privateAccess();

	}

}
