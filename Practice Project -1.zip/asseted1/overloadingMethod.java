package asseted1;

public class overloadingMethod {
	public void area(int a,int b) {
		System.out.println("Area of square : "+(a*b));
	}
	public void area(int r) {
		System.out.println("Area of the circle : "+(3.14*r*r));
	}
	public void area(int n, int m, int p) {
		System.out.println("Area of cuboid : "+(n*m*p));
	}
	
	public static void main(String[] args ) {
		
		overloadingMethod obj = new overloadingMethod();
		obj.area(10,20);
		obj.area(30,40,50);
		obj.area(60);
		
	}

}
