package asseted1;

public class Method3 {
	int a=50;
	int subtraction(int a) {
		a=a+1;
		return a;
		
		
	}

	public static void main(String[] args) {
		
		Method3 b=new Method3();
		System.out.println("value of a before calling the function : "+b.a);
		b.subtraction(30);
		System.out.println("value of c before calling the function : "+b.a);
		

	}

}
