package asseted1;

public class publicModifier2 {
	public void display() {
		System.out.println("This is public modifier2");
	}

}
