package accessModifier;
import asseted1.*;

public class publicModifier3 {

	public static void main(String[] args) {
		publicModifier2 b=new publicModifier2();
		b.display();

	}

}
